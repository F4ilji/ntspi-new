<template>
	<AdminLayout>
		<AdminFormLayout>
			<AdminFormHeader :title="'Добавить мероприятия'"/>
			<form @submit.prevent="submitForm">
				<AdminFormInput
						v-model="form.title"
						:error="form.errors.title"
						:placeholder="'Заголовок мероприятия'"
				/>

				<AdminFormInput class="mt-3"
						v-model="form.address"
						:error="form.errors.address"
						:placeholder="'Адрес'"
				/>

				<AdminFormInput class="mt-3"
						type="datetime-local"
						v-model="form.event_date"
						:error="form.errors.event_date"
						:placeholder="'Дата'"
				/>

				<AdminFormCheckbox class="mt-3"
						v-model="form.is_online"
						:label="'Мероприятие онлайн?'"
				/>
				<AdminFormEditorJs
						@get-content="getContentFromChildComponentEditorJs"
						:error="form.errors['content.blocks']"
						ref="editorJsComponent"
				/>

				<AdminFormButton
						v-bind="$attrs"
						type="submit"
						:title="'Создать мероприятие'"
				/>
			</form>
		</AdminFormLayout>
	</AdminLayout>
</template>

<script>
import {Link} from "@inertiajs/vue3";
import AdminLayout from "@/Layouts/AdminLayout.vue";
import AdminFormLayout from "@/Components/AdminFormLayout.vue";
import AdminFormHeader from "@/Components/AdminFormHeader.vue";
import AdminFormInput from "@/Components/AdminFormInput.vue";
import AdminFormSelect from "@/Components/AdminFormSelect.vue";
import AdminFormDropZone from "@/Components/AdminFormDropZone.vue";
import AdminFormCheckbox from "@/Components/AdminFormCheckbox.vue";
import AdminFormEditorJs from "@/Components/AdminFormEditorJs.vue";
import AdminFormButton from "@/Components/AdminFormButton.vue";

export default {
	name: "Create",
	components: {
		AdminFormButton,
		AdminFormEditorJs,
		AdminFormCheckbox,
		AdminFormDropZone,
		AdminFormSelect,
		AdminFormInput,
		AdminFormHeader,
		AdminFormLayout,
		AdminLayout,
		Link,
	},
	props: ["errors"],
	data() {
		return {
			form: this.$inertia.form({
				title: null,
				content: null,
				event_date: null,
				address: null,
				is_online: null,
			}),
		};
	},
	methods: {
		async submitForm() {
			await this.store();
		},
		store() {
			this.form.post(route("admin.event.store"));
		},
		async getContentFromChildComponentEditorJs(content) {
			const dataArray = JSON.parse(JSON.stringify(content));
			this.form.content = dataArray;
		},

	},
};
</script>

<style scoped></style>
