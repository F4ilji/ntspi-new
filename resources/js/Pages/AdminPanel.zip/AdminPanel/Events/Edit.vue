<template>
	<AdminLayout>
		<AdminFormLayout>
			<AdminFormHeader :title="'Изменить мероприятие'"/>
			<form @submit.prevent="submitForm">
				<AdminFormInput
						v-model="form.title"
						:error="form.errors.title"
						:placeholder="'Заголовок мероприятия'"
				/>

				<AdminFormInput class="mt-3"
												v-model="form.address"
												:error="form.errors.address"
												:placeholder="'Адрес'"
				/>

				<AdminFormInput class="mt-3"
												type="datetime-local"
												v-model="form.event_date"
												:error="form.errors.event_date"
												:placeholder="'Дата'"
				/>

				<AdminFormCheckbox class="mt-3"
													 v-model="form.is_online"
													 :label="'Мероприятие онлайн?'"
				/>
				<AdminFormEditorJs
						@get-content="getContentFromChildComponentEditorJs"
						:error="form.errors['content.blocks']"
						ref="editorJsComponent"
						:content-data="this.event.data.content"
				/>


				<AdminFormButton
						v-bind="$attrs"
						type="submit"
						:title="'Изменить мероприятие'"
				/>
			</form>
		</AdminFormLayout>
	</AdminLayout>

</template>

<script>

import {Link, useForm} from "@inertiajs/vue3";
import AdminLayout from "@/Layouts/AdminLayout.vue";
import EditorJS from "@editorjs/editorjs";
import AttachesTool from '@editorjs/attaches';
import Quote from '@editorjs/quote';
import ImageTool from '@editorjs/image';
import List from '@editorjs/list';
import AnyButton from 'editorjs-button';
import Paragraph from '@editorjs/paragraph';
import Header from '@editorjs/header';
import TextVariantTune from '@editorjs/text-variant-tune';
import AdminFormHeader from "@/Components/AdminFormHeader.vue";
import AdminFormLayout from "@/Components/AdminFormLayout.vue";
import AdminFormInput from "@/Components/AdminFormInput.vue";
import AdminFormSelect from "@/Components/AdminFormSelect.vue";
import AdminFormButton from "@/Components/AdminFormButton.vue";
import AdminFormEditorJs from "@/Components/AdminFormEditorJs.vue";
import AdminFormCheckbox from '@/Components/AdminFormCheckbox.vue';


export default {
	name: "Create",
	components: {
		AdminFormEditorJs,
		AdminFormButton,
		AdminFormSelect,
		AdminFormInput,
		AdminFormLayout,
		AdminFormHeader,
		AdminLayout,
		Link,
		AdminFormCheckbox
	},

	props: [
		'errors',
		'event'
	],
	data() {
		return {
			form: this.$inertia.form({
				title: this.event.data.title,
				content: this.event.data.content,
				event_date: this.event.data.event_date,
				is_online: this.event.data.is_online,
				address: this.event.data.address,
			}),
		}
	},
	methods: {
		async submitForm() {
			await this.update()
		},
		update() {
			this.form.patch(route('admin.event.update', this.event.data.id))

		},
		async getContentFromChildComponentEditorJs(content) {
			const dataArray = JSON.parse(JSON.stringify(content));
			this.form.content = dataArray
		},
	},

}
</script>


<style scoped>

</style>
