<template>
<AdminLayout>

        <!-- Page Heading -->

        <!-- End Page Heading -->
</AdminLayout>
</template>
<script setup>
import AdminLayout from "@/Layouts/AdminLayout.vue";
</script>
