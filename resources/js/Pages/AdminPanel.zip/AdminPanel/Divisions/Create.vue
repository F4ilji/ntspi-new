<template>
	<AdminLayout>
		<AdminFormLayout>
			<AdminFormHeader :title="'Добавить отдел'"/>
			<form @submit.prevent="submitForm">
				<AdminFormInput class="mb-4"
						v-model="form.title"
						:error="form.errors.title"
						:placeholder="'Заголовок новости'"
				/>

				<AdminFormEditorJs
						@get-content="getContentFromChildComponentEditorJs"
						:error="form.errors['content.blocks']"
						ref="editorJsComponent"
				/>

				<AdminFormButton
						v-bind="$attrs"
						type="submit"
						:title="'Создать новость'"
				/>

			</form>
		</AdminFormLayout>
	</AdminLayout>
</template>

<script>
import {Link} from "@inertiajs/vue3";
import AdminLayout from "@/Layouts/AdminLayout.vue";
import AdminFormLayout from "@/Components/AdminFormLayout.vue";
import AdminFormHeader from "@/Components/AdminFormHeader.vue";
import AdminFormInput from "@/Components/AdminFormInput.vue";
import AdminFormSelect from "@/Components/AdminFormSelect.vue";
import AdminFormDropZone from "@/Components/AdminFormDropZone.vue";
import AdminFormCheckbox from "@/Components/AdminFormCheckbox.vue";
import AdminFormEditorJs from "@/Components/AdminFormEditorJs.vue";
import AdminFormButton from "@/Components/AdminFormButton.vue";

export default {
	name: "Create",
	components: {
		AdminFormButton,
		AdminFormEditorJs,
		AdminFormCheckbox,
		AdminFormDropZone,
		AdminFormSelect,
		AdminFormInput,
		AdminFormHeader,
		AdminFormLayout,
		AdminLayout,
		Link,
	},
	props: ["errors", "categories"],
	data() {
		return {
			form: this.$inertia.form({
				title: null,
				description: null,
			}),
		};
	},
	methods: {
		async submitForm() {
			await this.store();
		},
		store() {
			this.form.post(route("admin.division.store"));
		},
		async getImageFromChildComponentDropZone(images) {
			if (images) {
				this.form.images = images;
			}
		},
		async getContentFromChildComponentEditorJs(content) {
			const dataArray = JSON.parse(JSON.stringify(content));
			this.form.description = dataArray;
		},
		requestImageFromChildComponentDropZone() {
			this.$refs.dropzoneComponent.saveImages();
		},
		makeSearchData(data) {
			let result = "";

			data.blocks.forEach((block) => {
				if (block.type === "paragraph" || block.type === "header") {
					result += block.data.text + " ";
				} else if (block.type === "list") {
					block.data.items.forEach((item) => {
						result += item + " ";
					});
				}
			});
			this.form.search_data = result.replace(/[?.,;:]/g, "").toLowerCase();
		},
	},
};
</script>

<style scoped></style>
