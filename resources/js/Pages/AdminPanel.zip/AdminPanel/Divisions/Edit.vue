<template>
	<AdminLayout>
		<AdminFormLayout>
			<AdminFormHeader :title="'Изменить отдел'"/>

			<form @submit.prevent="submitForm">
				<AdminFormInput class="mb-4" v-model="form.title" :error="form.errors.title" :placeholder="'Заголовок отдела'"/>

				<AdminFormEditorJs @get-content="getContentFromChildComponentEditorJs"
													 :contentData="this.division.data.description"/>

				<div class="grid grid-cols-3 gap-4 items-center mb-4">
					<AdminFormSelect :items="this.users">
						<option disabled value="">Выберите пользователя</option>
					</AdminFormSelect>
					<AdminFormInput :placeholder="'Должность'"/>
					<AdminFormButton :title="'Добавить'"/>
				</div>

				<AdminFormButton :title="'Обновить'"/>

			</form>
		</AdminFormLayout>
	</AdminLayout>

</template>

<script>

import {Link, useForm} from "@inertiajs/vue3";
import AdminLayout from "@/Layouts/AdminLayout.vue";
import EditorJS from "@editorjs/editorjs";
import AttachesTool from '@editorjs/attaches';
import Quote from '@editorjs/quote';
import ImageTool from '@editorjs/image';
import List from '@editorjs/list';
import AnyButton from 'editorjs-button';
import Paragraph from '@editorjs/paragraph';
import Header from '@editorjs/header';
import TextVariantTune from '@editorjs/text-variant-tune';
import AdminFormHeader from "@/Components/AdminFormHeader.vue";
import AdminFormLayout from "@/Components/AdminFormLayout.vue";
import AdminFormInput from "@/Components/AdminFormInput.vue";
import AdminFormSelect from "@/Components/AdminFormSelect.vue";
import AdminFormButton from "@/Components/AdminFormButton.vue";
import AdminFormEditorJs from "@/Components/AdminFormEditorJs.vue";
import AdminFormCheckbox from '@/Components/AdminFormCheckbox.vue';


export default {
	name: "Create",
	components: {
		AdminFormEditorJs,
		AdminFormButton,
		AdminFormSelect,
		AdminFormInput,
		AdminFormLayout,
		AdminFormHeader,
		AdminLayout,
		Link,
		AdminFormCheckbox
	},

	props: [
		'errors',
		'division',
		'users'
	],
	data() {
		return {
			form: this.$inertia.form({
				title: this.division.data.title,
				description: this.division.data.description,
				users_ids: null,
			}),
		}
	},
	methods: {
		async submitForm() {
			await this.update()
		},
		update() {
			this.form.patch(route('admin.division.update', this.division.data.id))

		},
		async getContentFromChildComponentEditorJs(content) {
			const dataArray = JSON.parse(JSON.stringify(content));
			this.form.description = dataArray
		},
	},

}
</script>


<style scoped>

</style>
